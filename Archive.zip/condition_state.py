"""Condition-state dispatcher — dynamic SAFE / CORE_THREAT / ECONOMY_THREAT /
STARVATION signal, computed fresh every round per unit.

Read-only layer on top of MapKnowledge sightings (slots 1-2) + this unit's
own vision — no new full-map scans. Nothing in this module calls a mutating
``ct.*`` method or changes builder behavior; it only answers "what's the
situation right now."

Priority when multiple are true: STARVATION > CORE_THREAT > ECONOMY_THREAT >
SAFE (see ``get_condition_state``).
"""

from __future__ import annotations

from fcode import Controller, EntityType, Position

from constants import (
    CORE_THREAT_RANGE_SQ_BUILDER,
    CORE_THREAT_RANGE_SQ_GUNNER,
    CORE_THREAT_RANGE_SQ_SENTINEL,
    ECONOMY_THREAT_RADIUS_SQ,
    STARVATION_PER_UNIT_BUFFER,
    STARVATION_RESERVE,
    STARVATION_ROUNDS,
)
from geometry import nearest_core_tile
import map_knowledge
from team_store import read_own_core

SAFE = "safe"
CORE_THREAT = "core_threat"
ECONOMY_THREAT = "economy_threat"
STARVATION = "starvation"

# Mirrors map_knowledge.py's private sighting type codes (1=harvester,
# 2=conveyor, 3=gunner, 4=sentinel, 5=launcher, 6=other) — not imported
# directly since they're module-private there; keep numerically in sync.
_SIGHT_GUNNER = 3
_SIGHT_SENTINEL = 4

_SIGHT_RANGE_SQ = {
    _SIGHT_GUNNER: CORE_THREAT_RANGE_SQ_GUNNER,
    _SIGHT_SENTINEL: CORE_THREAT_RANGE_SQ_SENTINEL,
}

# --- Per-unit module state — same-unit cross-round only (engine isolates
# module namespaces per living unit; see map_knowledge.py / claim_manager.py
# for the same pattern). Team-wide consensus is therefore approximate: a
# freshly spawned builder starts its own streak at 0. Acceptable per Stage 1
# spec — this only delays a defense-spend gate by a few rounds, never opens
# an idle window.
_low_resource_streak = 0
_last_streak_round = -1


def get_core_threats(ct: Controller, core: Position) -> list[Position]:
    """Enemy gunner/sentinel/builder positions within real firing range of Core."""
    hits: list[Position] = []

    for pos, type_code, _seen in map_knowledge.read_sightings(ct):
        range_sq = _SIGHT_RANGE_SQ.get(type_code)
        if range_sq is None:
            continue
        anchor = nearest_core_tile(pos, core)
        if anchor.distance_squared(pos) <= range_sq:
            hits.append(pos)

    my_team = ct.get_team()
    try:
        buildings = ct.get_nearby_buildings()
    except Exception:
        buildings = []
    for uid in buildings:
        try:
            if ct.get_team(uid) == my_team:
                continue
            et = ct.get_entity_type(uid)
            if et == EntityType.GUNNER:
                range_sq = CORE_THREAT_RANGE_SQ_GUNNER
            elif et == EntityType.SENTINEL:
                range_sq = CORE_THREAT_RANGE_SQ_SENTINEL
            else:
                continue
            pos = ct.get_position(uid)
        except Exception:
            continue
        anchor = nearest_core_tile(pos, core)
        if anchor.distance_squared(pos) <= range_sq:
            hits.append(pos)

    my_id = ct.get_id()
    try:
        units = ct.get_nearby_units()
    except Exception:
        units = []
    for uid in units:
        try:
            if uid == my_id:
                continue
            if ct.get_team(uid) == my_team:
                continue
            if ct.get_entity_type(uid) != EntityType.BUILDER_BOT:
                continue
            pos = ct.get_position(uid)
        except Exception:
            continue
        anchor = nearest_core_tile(pos, core)
        if anchor.distance_squared(pos) <= CORE_THREAT_RANGE_SQ_BUILDER:
            hits.append(pos)

    seen: set[tuple[int, int]] = set()
    out: list[Position] = []
    for p in hits:
        key = (p.x, p.y)
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def get_threatened_structures(ct: Controller) -> list[Position]:
    """Friendly harvester/conveyor/splitter tiles with a visible enemy within
    ECONOMY_THREAT_RADIUS_SQ right now. Public — Stage 2 (defense.py) uses
    this to pick a repair target."""
    friendlies = _friendly_structure_positions(ct)
    if not friendlies:
        return []

    my_team = ct.get_team()
    my_id = ct.get_id()
    enemy_positions: list[Position] = []
    try:
        units = ct.get_nearby_units()
    except Exception:
        units = []
    for uid in units:
        try:
            if uid == my_id:
                continue
            if ct.get_team(uid) == my_team:
                continue
            # get_nearby_units() is not builder-bots-only (it also surfaces
            # e.g. the enemy Core) — filter explicitly, same as
            # get_core_threats()'s own units loop.
            if ct.get_entity_type(uid) != EntityType.BUILDER_BOT:
                continue
            enemy_positions.append(ct.get_position(uid))
        except Exception:
            continue
    try:
        buildings = ct.get_nearby_buildings()
    except Exception:
        buildings = []
    for uid in buildings:
        try:
            if ct.get_team(uid) == my_team:
                continue
            et = ct.get_entity_type(uid)
            if et not in (EntityType.GUNNER, EntityType.SENTINEL, EntityType.LAUNCHER):
                continue
            enemy_positions.append(ct.get_position(uid))
        except Exception:
            continue

    if not enemy_positions:
        return []
    return [
        f
        for f in friendlies
        if any(f.distance_squared(e) <= ECONOMY_THREAT_RADIUS_SQ for e in enemy_positions)
    ]


def _friendly_structure_positions(ct: Controller) -> list[Position]:
    """Friendly harvester/conveyor/splitter tiles visible to this unit right now."""
    my_team = ct.get_team()
    out: list[Position] = []
    try:
        buildings = ct.get_nearby_buildings()
    except Exception:
        buildings = []
    for uid in buildings:
        try:
            if ct.get_team(uid) != my_team:
                continue
            et = ct.get_entity_type(uid)
            if et not in (
                EntityType.HARVESTER,
                EntityType.CONVEYOR,
                EntityType.SPLITTER,
            ):
                continue
            out.append(ct.get_position(uid))
        except Exception:
            continue
    return out


def _starving(ct: Controller) -> bool:
    """N consecutive rounds below a living-unit-count-scaled resource floor."""
    global _low_resource_streak, _last_streak_round
    rnd = ct.get_current_round()
    if rnd == _last_streak_round:
        return _low_resource_streak >= STARVATION_ROUNDS
    _last_streak_round = rnd

    try:
        unit_count = max(1, ct.get_unit_count())
    except Exception:
        unit_count = 1
    threshold = STARVATION_RESERVE + STARVATION_PER_UNIT_BUFFER * unit_count

    if ct.get_global_resources() < threshold:
        _low_resource_streak += 1
    else:
        _low_resource_streak = 0
    return _low_resource_streak >= STARVATION_ROUNDS


def get_condition_state(ct: Controller) -> str:
    """This unit's read of the team's current tactical situation, this round.

    Cheap: MapKnowledge sightings + this unit's own vision only, no new
    full-map scans. Priority when multiple are true: STARVATION >
    CORE_THREAT > ECONOMY_THREAT > SAFE.
    """
    if _starving(ct):
        return STARVATION

    core = read_own_core(ct)
    if get_core_threats(ct, core):
        return CORE_THREAT

    if get_threatened_structures(ct):
        return ECONOMY_THREAT

    return SAFE


def reset_for_tests() -> None:
    global _low_resource_streak, _last_streak_round
    _low_resource_streak = 0
    _last_streak_round = -1
