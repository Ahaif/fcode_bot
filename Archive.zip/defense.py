"""Defense: place outward-facing gunners in a ring around our Core, and react
to CORE_THREAT / ECONOMY_THREAT from condition_state.py.

Gunners need global ammo — the Core converts Ti→ammo via ``convert_ammo``.
Builders only place the turrets; ``roles/gunner_role.py`` handles firing.
"""

from __future__ import annotations

from fcode import Controller, Direction, EntityType, Position

import claim_manager
import condition_state
from assignment import get_assignment
from constants import (
    CARDINALS,
    DEFEND_BUILD_MAX_FROM_TRIGGER,
    DEFENSE_RING_SQ,
    MAX_GUNNERS,
    TITANIUM_RESERVE,
)
from geometry import builder_can_act, facing_away_from, facing_toward
from navigator import step_to
from team_store import bump_gunner_count, read_gunner_count


def count_visible_friendly_gunners(ct: Controller) -> int:
    my_team = ct.get_team()
    n = 0
    for uid in ct.get_nearby_buildings():
        if ct.get_entity_type(uid) == EntityType.GUNNER and ct.get_team(uid) == my_team:
            n += 1
    return n


def try_build_gunner(
    ct: Controller, core: Position, *, face_target: Position | None = None
) -> bool:
    """Build one gunner on an orthogonal neighbour tile.

    Faces away from Core by default (outward ring). When ``face_target`` is
    given (a known threat position), faces toward it instead — no separate
    ``rotate()`` call needed since facing is set at build time, for free.
    """
    if not builder_can_act(ct):
        return False
    if read_gunner_count(ct) >= MAX_GUNNERS:
        return False
    cost = ct.get_gunner_cost()
    if ct.get_global_resources() < cost + TITANIUM_RESERVE:
        return False

    pos = ct.get_position()
    # Face away from Core by default — unchanged from the pre-Stage-2 ring
    # behavior (computed once from the builder's own stand tile).
    default_facing = facing_away_from(pos, core)
    if default_facing == Direction.CENTRE:
        default_facing = Direction.EAST

    # Prefer tiles farther from Core (outer ring).
    tiles = sorted(
        (pos.add(d) for d in CARDINALS),
        key=lambda t: (-t.distance_squared(core), t.x, t.y),
    )
    for tile in tiles:
        facing = facing_toward(tile, face_target) if face_target is not None else default_facing
        if ct.can_build_gunner(tile, facing):
            ct.build_gunner(tile, facing)
            bump_gunner_count(ct)
            return True
    return False


def defend_step(
    ct: Controller,
    state: object,
    *,
    avoid: Position | None,
) -> None:
    """One defensive round: place a gunner near Core, else walk toward Core."""
    core = getattr(state, "core_pos", None)
    if core is None:
        return

    pos = ct.get_position()
    near_core = pos.distance_squared(core) <= DEFENSE_RING_SQ

    if near_core and try_build_gunner(ct, core):
        return

    # Not in the ring yet (or no legal gunner tile) — move toward Core.
    step_to(ct, state, core, avoid=avoid)


# ---------------------------------------------------------------------------
# Reactive CORE_THREAT response — dynamic turret dispatch (Stage 2, v1).
#
# Deliberately simple, per docs/PROGRESS_TRACKER.md Phase 4: one turret per
# distinct cardinal approach direction, capped at DEFEND_BUILD_MAX_FROM_TRIGGER
# builders per trigger. No new comm-store slot — builders_needed is naturally
# self-limiting (each already-built turret shrinks it for the next round's
# evaluators) and eligible-builder ranking reuses claim_manager's existing
# decentralized, locally-visible contest pattern (see claim_manager.py
# module docstring for the same "same-round races" caveat: builders that
# can't see each other may occasionally both decide they're needed).
# ---------------------------------------------------------------------------


def core_threat_direction(core: Position, threat: Position) -> Direction:
    """Cardinal bucket of a threat's approach, from the Core."""
    d = core.cardinal_direction_to(threat)
    if d == Direction.CENTRE:
        return Direction.NORTH
    return d


def target_turret_count(ct: Controller, core: Position) -> int:
    """One turret per distinct threat approach direction (v1 — no overbuild)."""
    threats = condition_state.get_core_threats(ct, core)
    return len({core_threat_direction(core, t) for t in threats})


def turrets_near_core(ct: Controller, core: Position) -> int:
    """Visible friendly gunners already within the Core defense ring."""
    my_team = ct.get_team()
    n = 0
    try:
        buildings = ct.get_nearby_buildings()
    except Exception:
        buildings = []
    for uid in buildings:
        try:
            if ct.get_entity_type(uid) != EntityType.GUNNER:
                continue
            if ct.get_team(uid) != my_team:
                continue
            if ct.get_position(uid).distance_squared(core) > DEFENSE_RING_SQ:
                continue
        except Exception:
            continue
        n += 1
    return n


def builders_needed_for_defense(ct: Controller, core: Position) -> int:
    needed = target_turret_count(ct, core) - turrets_near_core(ct, core)
    return max(0, min(DEFEND_BUILD_MAX_FROM_TRIGGER, needed))


def _eligible_defenders_rank(ct: Controller, state: object, core: Position) -> list[int]:
    """Locally-visible claim-free friendly builder ids, nearest-Core first."""
    my_id = ct.get_id()
    candidates: list[tuple[int, int]] = []
    if get_assignment(state).ore_pos is None:
        candidates.append((ct.get_position().distance_squared(core), my_id))

    my_team = ct.get_team()
    try:
        units = ct.get_nearby_units()
    except Exception:
        units = []
    for uid in units:
        if uid == my_id:
            continue
        try:
            if ct.get_team(uid) != my_team:
                continue
            if ct.get_entity_type(uid) != EntityType.BUILDER_BOT:
                continue
            if claim_manager.builder_claim(ct, uid) is not None:
                continue
            pos = ct.get_position(uid)
        except Exception:
            continue
        candidates.append((pos.distance_squared(core), uid))

    candidates.sort()
    return [uid for _dist, uid in candidates]


def should_enter_defend_build(ct: Controller, state: object, core: Position) -> bool:
    """True if this free builder is one of the nearest N needed for CORE_THREAT."""
    if get_assignment(state).ore_pos is not None:
        return False
    needed = builders_needed_for_defense(ct, core)
    if needed <= 0:
        return False
    ranked = _eligible_defenders_rank(ct, state, core)
    try:
        idx = ranked.index(ct.get_id())
    except ValueError:
        return False
    return idx < needed


def defend_build_step(
    ct: Controller,
    state: object,
    core: Position,
    *,
    avoid: Position | None,
) -> bool:
    """One DEFEND_BUILD round. Returns True when this builder is done (turret
    built, or no threat left to answer) and should return to normal behavior
    this same round — caller re-checks CORE_THREAT before calling this at all,
    so a STARVATION/threat-cleared exit is handled by the caller, not here.
    """
    threats = condition_state.get_core_threats(ct, core)
    if not threats:
        return True

    pos = ct.get_position()
    if pos.distance_squared(core) <= DEFENSE_RING_SQ:
        nearest_threat = min(threats, key=lambda t: pos.distance_squared(t))
        if try_build_gunner(ct, core, face_target=nearest_threat):
            return True
        return False

    step_to(ct, state, core, avoid=avoid)
    return False


# ---------------------------------------------------------------------------
# Reactive ECONOMY_THREAT response — repair only, never builds anything new.
# ---------------------------------------------------------------------------


def try_repair_adjacent(ct: Controller) -> bool:
    """Heal an orthogonally adjacent damaged friendly harvester/conveyor/splitter."""
    if not builder_can_act(ct):
        return False
    pos = ct.get_position()
    my_team = ct.get_team()
    for d in CARDINALS:
        tile = pos.add(d)
        try:
            bid = ct.get_tile_building_id(tile)
            if bid is None:
                continue
            if ct.get_team(bid) != my_team:
                continue
            et = ct.get_entity_type(bid)
            if et not in (EntityType.HARVESTER, EntityType.CONVEYOR, EntityType.SPLITTER):
                continue
        except Exception:
            continue
        if ct.can_heal(tile):
            ct.heal(tile)
            return True
    return False


def economy_defend_step(
    ct: Controller,
    state: object,
    *,
    avoid: Position | None,
) -> bool:
    """One ECONOMY_THREAT round for a free builder: repair if adjacent and
    able, else approach the nearest threatened friendly structure. Never
    builds/spawns anything — cheaper response only (Phase 4 spec).
    """
    threatened = condition_state.get_threatened_structures(ct)
    if not threatened:
        return False
    if try_repair_adjacent(ct):
        return True
    pos = ct.get_position()
    target = min(threatened, key=lambda t: pos.distance_squared(t))
    step_to(ct, state, target, avoid=avoid)
    return True
