"""Tuning knobs, store slots, and builder phase names.

Keep magic numbers here so roles stay readable. Costs always come from
``ct.get_*_cost()`` at runtime — never hardcode titanium amounts for builds.
"""

from __future__ import annotations

from fcode import Direction

# ---------------------------------------------------------------------------
# Directions
# ---------------------------------------------------------------------------

CARDINALS = (
    Direction.NORTH,
    Direction.EAST,
    Direction.SOUTH,
    Direction.WEST,
)

# Deterministic spawn try-order (cardinals first, then diagonals).
SPAWN_DIRS = (
    Direction.NORTH,
    Direction.EAST,
    Direction.SOUTH,
    Direction.WEST,
    Direction.NORTHEAST,
    Direction.SOUTHEAST,
    Direction.SOUTHWEST,
    Direction.NORTHWEST,
)

# ---------------------------------------------------------------------------
# Comm store (writes visible next round only; values are u32)
# ---------------------------------------------------------------------------

# Slot 0: packed team meta (own/enemy core + known + gunner count).
# See team_store.py for pack layout and helpers — do not decode raw.
SLOT_TEAM_META = 0
# Slots 1-2: enemy building sightings (MapKnowledge, Stage B).
SLOT_SIGHTING_0 = 1
SLOT_SIGHTING_1 = 2
# Slot 3: choke hint (MapKnowledge, Stage B).
SLOT_CHOKE_HINT = 3
# Slots 4-5: reserved for Phase 4 (defense) / Phase 5 (offense) — leave 0.
SLOT_RESERVED_PHASE4 = 4
SLOT_RESERVED_PHASE5 = 5
# Slots 6..15: ore claim board (unchanged).
# Pack: builder_id * 100000 + x * 256 + y + 1
SLOT_CLAIM_BASE = 6
MAX_ORE_CLAIMS = 10  # slots 6..15 inclusive

# ---------------------------------------------------------------------------
# Economy / army size
# ---------------------------------------------------------------------------

MAX_BUILDERS = 7
MAX_GUNNERS = 4
AMMO_CONVERT_CHUNK = 20
# Keep this much Ti in the global pool before converting ammo / building guns.
TITANIUM_RESERVE = 40

# ---------------------------------------------------------------------------
# Movement / exploration
# ---------------------------------------------------------------------------

STUCK_LIMIT = 3
# Belt plan may replan this many times before FAILED_TASK.
MAX_BELT_REPLANS = 6
# After this many sector-waypoint advances with no ore, switch to defend/attack.
WAYPOINTS_BEFORE_COMBAT = 12

# Stay near the Core when placing defensive gunners (distance²).
DEFENSE_RING_SQ = 18

# ---------------------------------------------------------------------------
# Condition state (condition_state.py) — dynamic SAFE/CORE_THREAT/
# ECONOMY_THREAT/STARVATION dispatcher. See docs/PROGRESS_TRACKER.md Phase 4/5.
# ---------------------------------------------------------------------------

# Real attack-range constants from docs/CONTROLLER_API.md (distance², tile²).
CORE_THREAT_RANGE_SQ_GUNNER = 13
CORE_THREAT_RANGE_SQ_SENTINEL = 32
# Builder bots have no ranged attack — melee needs orthogonal adjacency to
# the Core footprint (distance² 1), +1 tile of margin so we react the round
# before it's actually adjacent, not the round after.
CORE_THREAT_RANGE_SQ_BUILDER = 2

# Enemy unit/building within this distance² of a friendly harvester/conveyor
# counts as pressuring our economy (not the Core itself).
ECONOMY_THREAT_RADIUS_SQ = 50

# STARVATION: global_resources held below (reserve + per-unit buffer *
# living unit count) for this many consecutive rounds.
STARVATION_ROUNDS = 5
STARVATION_RESERVE = TITANIUM_RESERVE
STARVATION_PER_UNIT_BUFFER = 6

# At most this many builders get pulled into DEFEND_BUILD per CORE_THREAT
# trigger (docs/PROGRESS_TRACKER.md Phase 4 — "v1", not full coverage logic).
DEFEND_BUILD_MAX_FROM_TRIGGER = 2

# ---------------------------------------------------------------------------
# Offense dispatch (Stage 3, Phase 5) — one capped attack-dedicated builder.
# Team-wide holder tracked in comm-store slot 5 (SLOT_RESERVED_PHASE5).
# ---------------------------------------------------------------------------

# Only dispatch a new attacker when resources are comfortably above
# (builder_bot_cost + this buffer) — we could afford to replace this builder
# if it dies, without starving the economy.
ATTACK_RESOURCE_BUFFER = 60
# Recall once HP falls to/below this fraction of max HP.
ATTACK_HP_RETREAT_FRACTION = 0.35
# Recall after this many consecutive rounds with no progress toward target.
ATTACK_STALL_ROUNDS = 8

# ---------------------------------------------------------------------------
# Builder FSM (authoritative ``state.phase``)
#
#   EXPLORE → MOVE_TO_STAND → BUILD_HARVESTER → PLAN_CONVEYOR
#          → BUILD_CONVEYOR → RETURN_HOME → COMPLETE_TASK → EXPLORE
#                              ↘ FAILED_TASK → EXPLORE
#          ↘ DEFEND / ATTACK (late game)
#
# Conveyors follow a persistent build_plan; no per-turn greedy neighbours.
# ---------------------------------------------------------------------------

PHASE_EXPLORE = "explore"
PHASE_MOVE_TO_STAND = "move_to_stand"
PHASE_BUILD_HARVESTER = "build_harvester"
PHASE_PLAN_CONVEYOR = "plan_conveyor"
PHASE_BUILD_CONVEYOR = "build_conveyor"
PHASE_RETURN_HOME = "return_home"
PHASE_COMPLETE_TASK = "complete_task"
PHASE_FAILED_TASK = "failed_task"
PHASE_DEFEND = "defend"
PHASE_ATTACK = "attack"
# Reactive turret-build response to CORE_THREAT (condition_state.py). Distinct
# from the static late-game PHASE_DEFEND ring — re-checked every round, no
# latching; exits back to EXPLORE the same round it finishes or the threat
# clears (see roles/builder_role.py).
PHASE_DEFEND_BUILD = "defend_build"

# Back-compat aliases used by older tests / docs.
PHASE_APPROACH_ORE = PHASE_MOVE_TO_STAND
PHASE_BELT_TO_CORE = PHASE_BUILD_CONVEYOR
