"""Offense: smash enemy harvesters and push the enemy Core.

Builders deal 2 damage for 2 Ti on an orthogonally adjacent building
(``can_fire`` / ``fire``). Prefer enemy harvesters, then any enemy building,
then walk toward a known / guessed enemy Core.
"""

from __future__ import annotations

from fcode import Controller, EntityType, Position

import claim_manager
import team_store
from assignment import get_assignment
from constants import (
    ATTACK_HP_RETREAT_FRACTION,
    ATTACK_RESOURCE_BUFFER,
    ATTACK_STALL_ROUNDS,
    CARDINALS,
)
from geometry import builder_can_act, in_bounds
from navigator import step_to
from team_store import read_enemy_core, write_enemy_core


def note_enemy_core(ct: Controller) -> None:
    """If the enemy Core is in vision, publish it for the rest of the team."""
    my_team = ct.get_team()
    for uid in ct.get_nearby_buildings():
        if ct.get_entity_type(uid) != EntityType.CORE:
            continue
        if ct.get_team(uid) == my_team:
            continue
        write_enemy_core(ct, ct.get_position(uid))
        return


def enemy_core_target(ct: Controller, own_core: Position | None) -> Position | None:
    """Known enemy Core from the store, else rotational symmetry guess."""
    known = read_enemy_core(ct)
    if known is not None:
        return known
    # Most league maps are rotationally symmetric: (x,y) → (W-1-x, H-1-y).
    if own_core is not None:
        w, h = ct.get_map_width(), ct.get_map_height()
        return Position(w - 1 - own_core.x, h - 1 - own_core.y)
    return None


def _enemy_building_on(ct: Controller, tile: Position) -> EntityType | None:
    if not in_bounds(ct, tile):
        return None
    try:
        if not ct.is_in_vision(tile):
            return None
        bid = ct.get_tile_building_id(tile)
        if bid is None:
            return None
        if ct.get_team(bid) == ct.get_team():
            return None
        return ct.get_entity_type(bid)
    except Exception:
        return None


def try_attack_adjacent(ct: Controller) -> bool:
    """Attack an orthogonally adjacent enemy building. Prefer harvesters."""
    if not builder_can_act(ct):
        return False
    # Builder melee costs 2 Ti — skip if broke.
    if ct.get_global_resources() < 2:
        return False

    pos = ct.get_position()
    harvester_tiles: list[Position] = []
    other_tiles: list[Position] = []
    for d in CARDINALS:
        tile = pos.add(d)
        et = _enemy_building_on(ct, tile)
        if et is None:
            continue
        if et == EntityType.HARVESTER:
            harvester_tiles.append(tile)
        elif et != EntityType.CORE:
            other_tiles.append(tile)
        else:
            other_tiles.append(tile)

    for tile in harvester_tiles + other_tiles:
        if ct.can_fire(tile):
            ct.fire(tile)
            return True
    return False


def nearest_enemy_harvester(ct: Controller) -> Position | None:
    """Closest visible enemy harvester tile, or None."""
    pos = ct.get_position()
    my_team = ct.get_team()
    best: Position | None = None
    best_key: tuple[int, int, int] | None = None
    for uid in ct.get_nearby_buildings():
        if ct.get_entity_type(uid) != EntityType.HARVESTER:
            continue
        if ct.get_team(uid) == my_team:
            continue
        tile = ct.get_position(uid)
        key = (pos.distance_squared(tile), tile.x, tile.y)
        if best_key is None or key < best_key:
            best_key = key
            best = tile
    return best


def attack_step(
    ct: Controller,
    state: object,
    *,
    avoid: Position | None,
) -> None:
    """One offensive round: melee if adjacent, else march toward a target."""
    note_enemy_core(ct)

    if try_attack_adjacent(ct):
        return

    target = nearest_enemy_harvester(ct)
    if target is None:
        target = enemy_core_target(ct, getattr(state, "core_pos", None))
    if target is None:
        # Last resort: map centre (often contested mid).
        target = Position(ct.get_map_width() // 2, ct.get_map_height() // 2)

    state.attack_target = target  # type: ignore[attr-defined]
    step_to(ct, state, target, avoid=avoid)


# ---------------------------------------------------------------------------
# Reactive offense dispatch — one capped attack-dedicated builder (Stage 3,
# v1). Same decentralized, locally-visible contest pattern as defense.py's
# DEFEND_BUILD dispatch and claim_manager.py's ownership protocol — every
# free builder independently agrees on the single nearest candidate.
# Team-wide holder tracked in comm-store slot 5 (team_store.py).
# ---------------------------------------------------------------------------


def attack_slot_holder_alive(ct: Controller) -> bool:
    """True if the comm-store-recorded dedicated attacker is still alive & ours."""
    holder = team_store.read_attack_builder_id(ct)
    if holder <= 0:
        return False
    try:
        if ct.get_team(holder) != ct.get_team():
            return False
        if ct.get_entity_type(holder) != EntityType.BUILDER_BOT:
            return False
    except Exception:
        return False
    return True


def _eligible_attacker_rank(ct: Controller, state: object, core: Position) -> list[int]:
    """Locally-visible claim-free friendly builder ids, nearest-Core first."""
    my_id = ct.get_id()
    candidates: list[tuple[int, int]] = []
    if get_assignment(state).ore_pos is None:
        candidates.append((ct.get_position().distance_squared(core), my_id))

    my_team = ct.get_team()
    try:
        units = ct.get_nearby_units()
    except Exception:
        units = []
    for uid in units:
        if uid == my_id:
            continue
        try:
            if ct.get_team(uid) != my_team:
                continue
            if ct.get_entity_type(uid) != EntityType.BUILDER_BOT:
                continue
            if claim_manager.builder_claim(ct, uid) is not None:
                continue
            pos = ct.get_position(uid)
        except Exception:
            continue
        candidates.append((pos.distance_squared(core), uid))

    candidates.sort()
    return [uid for _dist, uid in candidates]


def should_dispatch_attacker(ct: Controller, state: object, core: Position) -> bool:
    """True if this free builder should become the team's one dedicated attacker."""
    if get_assignment(state).ore_pos is not None:
        return False
    if attack_slot_holder_alive(ct):
        return False
    cost = ct.get_builder_bot_cost()
    if ct.get_global_resources() < cost + ATTACK_RESOURCE_BUFFER:
        return False
    ranked = _eligible_attacker_rank(ct, state, core)
    try:
        idx = ranked.index(ct.get_id())
    except ValueError:
        return False
    return idx == 0


def claim_attack_slot(ct: Controller, state: object) -> None:
    team_store.write_attack_builder_id(ct, ct.get_id())
    state.attack_stall_rounds = 0  # type: ignore[attr-defined]
    state.attack_last_dist = None  # type: ignore[attr-defined]
    state.attack_target = None  # type: ignore[attr-defined]


def should_recall_attacker(ct: Controller, state: object) -> bool:
    """True once the dedicated attacker should give up and rejoin the economy:
    HP at/below ATTACK_HP_RETREAT_FRACTION of max, or no progress toward its
    current target for ATTACK_STALL_ROUNDS consecutive rounds.
    """
    try:
        hp = ct.get_hp()
        max_hp = ct.get_max_hp()
        if max_hp > 0 and hp <= max_hp * ATTACK_HP_RETREAT_FRACTION:
            return True
    except Exception:
        pass

    target = getattr(state, "attack_target", None)
    if target is None:
        return False
    dist = ct.get_position().distance_squared(target)
    last_dist = getattr(state, "attack_last_dist", None)
    if last_dist is not None and dist >= last_dist:
        stall = getattr(state, "attack_stall_rounds", 0) + 1
    else:
        stall = 0
    state.attack_stall_rounds = stall  # type: ignore[attr-defined]
    state.attack_last_dist = dist  # type: ignore[attr-defined]
    return stall >= ATTACK_STALL_ROUNDS


def release_attack_slot(ct: Controller, state: object) -> None:
    """Clear the team-wide attack slot iff this builder currently holds it."""
    if team_store.read_attack_builder_id(ct) == ct.get_id():
        team_store.clear_attack_builder_id(ct)
    state.attack_stall_rounds = 0  # type: ignore[attr-defined]
    state.attack_last_dist = None  # type: ignore[attr-defined]
